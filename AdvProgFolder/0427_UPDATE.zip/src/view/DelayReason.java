package view;

public class DelayReason
{
	public int flightId=0;
	public String reason = "";
	public int reasonCount =0;
}
